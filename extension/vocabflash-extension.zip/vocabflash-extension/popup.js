import { CONFIG } from './config.js';
import { getSession, login, logout, addWord, defineWords, updateWord, pendingCount } from './api.js';

const $ = s => document.querySelector(s);
const msg = (el, text, ok) => { el.textContent = text; el.className = 'msg ' + (text ? (ok ? 'ok' : 'err') : ''); };
const openApp = (hash = '') => chrome.tabs.create({ url: CONFIG.APP_URL + hash });

async function render() {
  const s = await getSession();
  $('#login').hidden = !!s; $('#main').hidden = !s;
  if (s) {
    $('#userName').textContent = s.user.name || s.user.email;
    try { const n = await pendingCount(); $('#pending').textContent = n ? `📥 ${n} từ đang chờ trên web` : 'Hộp thư trống'; }
    catch (e) { $('#pending').textContent = ''; msg($('#mainMsg'), e.message, false); if (/đăng nhập/i.test(e.message)) render(); }
    $('#quickWord').focus();
  } else $('#email').focus();
}

$('#btnLogin').addEventListener('click', async () => {
  const b = $('#btnLogin'); b.disabled = true; msg($('#loginMsg'), '');
  try { await login($('#email').value, $('#password').value); await render(); }
  catch (e) { msg($('#loginMsg'), e.message, false); }
  finally { b.disabled = false; }
});
$('#password').addEventListener('keydown', e => { if (e.key === 'Enter') $('#btnLogin').click(); });
$('#btnLogout').addEventListener('click', async () => { await logout(); render(); });

// Thêm nhanh: nhiều từ cách nhau bằng dấu phẩy / chấm phẩy / xuống dòng → thêm hết, dịch cả loạt trong 1 lời gọi
const quick = async () => {
  const words = [...new Set($('#quickWord').value.split(/[,;\n]+/).map(w => w.replace(/\s+/g, ' ').trim()).filter(w => w && w.length <= 80))];
  if (!words.length) return;
  const b = $('#btnQuick'); b.disabled = true;
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const src = { url: tab?.url && /^https?:/.test(tab.url) ? tab.url : '', title: tab?.title || '' };
    const ids = await Promise.all(words.map(word => addWord({ word, ...src })));
    $('#quickWord').value = ''; msg($('#mainMsg'), `Đã thêm ${words.length} từ – ⏳ đang dịch...`, true); render();
    const defs = await defineWords(words.map(word => ({ word })));
    await Promise.all(defs.map((def, i) => def && ids[i] ? updateWord(ids[i], def) : null));
    const lines = words.map((w, i) => defs[i] ? `✔ ${defs[i].word || w} ${defs[i].phonetic} = ${defs[i].meaning}` : `✔ ${w} (chưa dịch được)`);
    msg($('#mainMsg'), lines.join('\n'), true);
  } catch (e) { msg($('#mainMsg'), e.message, false); }
  finally { b.disabled = false; }
};
$('#btnQuick').addEventListener('click', quick);
$('#quickWord').addEventListener('keydown', e => { if (e.key === 'Enter') quick(); });
$('#openApp1').addEventListener('click', e => { e.preventDefault(); openApp('#/'); });
$('#openApp2').addEventListener('click', e => { e.preventDefault(); openApp('#/inbox'); });

render();
